import {
  auth,
  db
} from "./firebase-config.js";

import {
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

import {
  addDoc,
  collection,
  getDocs,
  query,
  serverTimestamp,
  Timestamp,
  where
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

/* Profil Pensyarah */
const lecturerName =
  document.getElementById("lecturerName");

const lecturerEmail =
  document.getElementById("lecturerEmail");

const profilePhoto =
  document.getElementById("profilePhoto");

const logoutBtn =
  document.getElementById("logoutBtn");

/* Borang sesi */
const sessionForm =
  document.getElementById("sessionForm");

const classSelect =
  document.getElementById("classSelect");

const selectedCourseInfo =
  document.getElementById("selectedCourseInfo");

const topic =
  document.getElementById("topic");

const subtopicContainer =
  document.getElementById("subtopicContainer");

const addSubtopicBtn =
  document.getElementById("addSubtopicBtn");

const questionContainer =
  document.getElementById("questionContainer");

const addQuestionBtn =
  document.getElementById("addQuestionBtn");

const startAt =
  document.getElementById("startAt");

const endAt =
  document.getElementById("endAt");

const sessionStatus =
  document.getElementById("sessionStatus");

const sessionFormMessage =
  document.getElementById("sessionFormMessage");

const saveSessionBtn =
  document.getElementById("saveSessionBtn");

const resetSessionBtn =
  document.getElementById("resetSessionBtn");

/* Keputusan sesi */
const sessionResult =
  document.getElementById("sessionResult");

const sessionCodeDisplay =
  document.getElementById("sessionCodeDisplay");

const studentSessionLink =
  document.getElementById("studentSessionLink");

const copySessionLinkBtn =
  document.getElementById("copySessionLinkBtn");

const openStudentLink =
  document.getElementById("openStudentLink");

let currentLecturer = null;
let lecturerClasses = [];

function displayLecturer(lecturer) {
  const fullName =
    lecturer.displayName || "Pensyarah";

  lecturerName.textContent = fullName;
  lecturerEmail.textContent = lecturer.email || "";

  if (lecturer.photoURL) {
    profilePhoto.src = lecturer.photoURL;
    profilePhoto.alt = `Gambar profil ${fullName}`;
  } else {
    profilePhoto.removeAttribute("src");
  }
}

function showMessage(text, type) {
  sessionFormMessage.textContent = text;
  sessionFormMessage.className =
    `message show ${type}`;
}

function clearMessage() {
  sessionFormMessage.textContent = "";
  sessionFormMessage.className = "message";
}

function createOption(classData) {
  const option = document.createElement("option");

  option.value = classData.id;

  option.textContent =
    `${classData.className} — ${classData.courseCode}`;

  return option;
}

async function loadLecturerClasses(lecturerId) {
  classSelect.disabled = true;

  classSelect.innerHTML = `
    <option value="">
      Sedang mendapatkan kelas...
    </option>
  `;

  try {
    const classesQuery = query(
      collection(db, "classes"),
      where("lecturerId", "==", lecturerId)
    );

    const snapshot = await getDocs(classesQuery);

    lecturerClasses = snapshot.docs
      .map((classDocument) => ({
        id: classDocument.id,
        ...classDocument.data()
      }))
      .filter((classData) => classData.isActive)
      .sort((firstClass, secondClass) =>
        firstClass.className.localeCompare(
          secondClass.className
        )
      );

    classSelect.innerHTML = `
      <option value="">
        Pilih kelas
      </option>
    `;

    lecturerClasses.forEach((classData) => {
      classSelect.appendChild(
        createOption(classData)
      );
    });

    if (lecturerClasses.length === 0) {
      classSelect.innerHTML = `
        <option value="">
          Tiada kelas tersedia
        </option>
      `;

      selectedCourseInfo.textContent =
        "Cipta kelas terlebih dahulu melalui Kelas Saya.";
    }
  } catch (error) {
    console.error(
      "Kelas gagal diperoleh:",
      error
    );

    classSelect.innerHTML = `
      <option value="">
        Kelas gagal diperoleh
      </option>
    `;

    showMessage(
      `Kelas gagal diperoleh: ${
        error.code || "ralat-tidak-diketahui"
      }`,
      "error"
    );
  } finally {
    classSelect.disabled = false;
  }
}

function getSelectedClass() {
  return lecturerClasses.find(
    (classData) =>
      classData.id === classSelect.value
  );
}

function createDynamicField(
  fieldType,
  className,
  placeholder
) {
  const wrapper =
    document.createElement("div");

  wrapper.className = "dynamic-field";

  const field =
    document.createElement(fieldType);

  field.className = className;
  field.placeholder = placeholder;
  field.maxLength =
    fieldType === "textarea" ? 300 : 150;

  const removeButton =
    document.createElement("button");

  removeButton.type = "button";
  removeButton.className =
    "remove-field-button";

  removeButton.textContent = "×";
  removeButton.setAttribute(
    "aria-label",
    "Buang medan"
  );

  removeButton.addEventListener("click", () => {
    wrapper.remove();
  });

  wrapper.append(field, removeButton);

  return wrapper;
}

function getFieldValues(selector) {
  return [...document.querySelectorAll(selector)]
    .map((field) => field.value.trim())
    .filter(Boolean);
}

function generateSessionCode(
  courseCodeValue,
  classNameValue
) {
  const randomCode =
    Math.random()
      .toString(36)
      .slice(2, 6)
      .toUpperCase();

  const cleanCourse =
    courseCodeValue
      .replace(/[^a-zA-Z0-9]/g, "")
      .toUpperCase();

  const cleanClass =
    classNameValue
      .replace(/[^a-zA-Z0-9]/g, "")
      .toUpperCase();

  return `${cleanCourse}-${cleanClass}-${randomCode}`;
}

function createStudentLink(sessionId) {
  const studentURL = new URL(
    "student.html",
    window.location.href
  );

  studentURL.searchParams.set(
    "session",
    sessionId
  );

  return studentURL.href;
}

function resetDynamicFields() {
  subtopicContainer.innerHTML = `
    <div class="dynamic-field">
      <input
        type="text"
        class="subtopic-input"
        maxlength="150"
        placeholder="Contoh: Data Integrity"
        required
      >
    </div>
  `;

  questionContainer.innerHTML = `
    <div class="dynamic-field">
      <textarea
        class="question-input"
        maxlength="300"
        placeholder="Contoh: Terangkan maksud data integrity."
        required
      ></textarea>
    </div>
  `;
}

classSelect.addEventListener("change", () => {
  const selectedClass = getSelectedClass();

  if (!selectedClass) {
    selectedCourseInfo.textContent =
      "Kod dan nama kursus akan diambil " +
      "daripada kelas yang dipilih.";

    return;
  }

  selectedCourseInfo.textContent =
    `${selectedClass.courseCode} — ` +
    `${selectedClass.courseName}`;
});

addSubtopicBtn.addEventListener("click", () => {
  const totalSubtopics =
    document.querySelectorAll(
      ".subtopic-input"
    ).length;

  if (totalSubtopics >= 5) {
    window.alert(
      "Maksimum lima subtopik bagi satu sesi."
    );

    return;
  }

  const field = createDynamicField(
    "input",
    "subtopic-input",
    "Masukkan subtopik tambahan"
  );

  subtopicContainer.appendChild(field);
  field.querySelector("input").focus();
});

addQuestionBtn.addEventListener("click", () => {
  const totalQuestions =
    document.querySelectorAll(
      ".question-input"
    ).length;

  if (totalQuestions >= 5) {
    window.alert(
      "Maksimum lima soalan bagi satu sesi."
    );

    return;
  }

  const field = createDynamicField(
    "textarea",
    "question-input",
    "Masukkan soalan tambahan"
  );

  questionContainer.appendChild(field);
  field.querySelector("textarea").focus();
});

resetSessionBtn.addEventListener("click", () => {
  window.setTimeout(() => {
    resetDynamicFields();
    clearMessage();
    sessionResult.classList.add("hidden");

    selectedCourseInfo.textContent =
      "Kod dan nama kursus akan diambil " +
      "daripada kelas yang dipilih.";
  }, 0);
});

sessionForm.addEventListener(
  "submit",
  async (event) => {
    event.preventDefault();
    clearMessage();

    if (!currentLecturer) {
      showMessage(
        "Sesi log masuk Pensyarah tidak ditemui.",
        "error"
      );

      return;
    }

    const selectedClass = getSelectedClass();

    if (!selectedClass) {
      showMessage(
        "Sila pilih kelas.",
        "error"
      );

      return;
    }

    const subtopics =
      getFieldValues(".subtopic-input");

    const questions =
      getFieldValues(".question-input");

    if (subtopics.length === 0) {
      showMessage(
        "Masukkan sekurang-kurangnya satu subtopik.",
        "error"
      );

      return;
    }

    if (questions.length === 0) {
      showMessage(
        "Masukkan sekurang-kurangnya satu soalan.",
        "error"
      );

      return;
    }

    const startDate =
      new Date(startAt.value);

    const endDate =
      new Date(endAt.value);

    if (
      Number.isNaN(startDate.getTime()) ||
      Number.isNaN(endDate.getTime())
    ) {
      showMessage(
        "Tarikh dan masa sesi tidak sah.",
        "error"
      );

      return;
    }

    if (endDate <= startDate) {
      showMessage(
        "Masa tamat mestilah selepas masa mula.",
        "error"
      );

      return;
    }

    saveSessionBtn.disabled = true;
    saveSessionBtn.textContent =
      "Sedang mencipta sesi...";

    try {
      const sessionCode =
        generateSessionCode(
          selectedClass.courseCode,
          selectedClass.className
        );

      const sessionDocument =
        await addDoc(
          collection(db, "sessions"),
          {
            lecturerId: currentLecturer.uid,
            lecturerName:
              currentLecturer.displayName ||
              "Pensyarah",

            classId: selectedClass.id,
            className: selectedClass.className,
            courseCode:
              selectedClass.courseCode,
            courseName:
              selectedClass.courseName,

            topic: topic.value.trim(),
            subtopics,
            questions,

            sessionCode,
            status: sessionStatus.value,

            startAt:
              Timestamp.fromDate(startDate),
            endAt:
              Timestamp.fromDate(endDate),

            responseCount: 0,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          }
        );

      const studentLink =
        createStudentLink(sessionDocument.id);

      sessionCodeDisplay.textContent =
        sessionCode;

      studentSessionLink.value =
        studentLink;

      openStudentLink.href =
        studentLink;

      sessionResult.classList.remove("hidden");

      showMessage(
        "Sesi Exit Ticket berjaya dicipta.",
        "success"
      );

      sessionResult.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    } catch (error) {
      console.error(
        "Sesi gagal dicipta:",
        error
      );

      showMessage(
        `Sesi gagal dicipta: ${
          error.code || "ralat-tidak-diketahui"
        }`,
        "error"
      );
    } finally {
      saveSessionBtn.disabled = false;
      saveSessionBtn.textContent = "Cipta Sesi";
    }
  }
);

copySessionLinkBtn.addEventListener(
  "click",
  async () => {
    const link = studentSessionLink.value;

    if (!link) {
      return;
    }

    try {
      await navigator.clipboard.writeText(link);

      copySessionLinkBtn.textContent =
        "Sudah Disalin";

      window.setTimeout(() => {
        copySessionLinkBtn.textContent =
          "Salin Pautan";
      }, 1800);
    } catch (error) {
      studentSessionLink.select();
      document.execCommand("copy");

      copySessionLinkBtn.textContent =
        "Sudah Disalin";
    }
  }
);

onAuthStateChanged(auth, async (lecturer) => {
  if (!lecturer) {
    window.location.replace("index.html");
    return;
  }

  currentLecturer = lecturer;
  displayLecturer(lecturer);

  await loadLecturerClasses(lecturer.uid);
});

logoutBtn.addEventListener("click", async () => {
  const confirmed = window.confirm(
    "Adakah anda mahu log keluar?"
  );

  if (!confirmed) {
    return;
  }

  try {
    await signOut(auth);
    window.location.replace("index.html");
  } catch (error) {
    console.error("Ralat log keluar:", error);

    window.alert(
      "Log keluar tidak berjaya. Sila cuba semula."
    );
  }
});