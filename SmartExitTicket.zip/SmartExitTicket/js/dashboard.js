import {
  auth,
  db
} from "./firebase-config.js";

import {
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

const lecturerName =
  document.getElementById("lecturerName");

const lecturerEmail =
  document.getElementById("lecturerEmail");

const welcomeName =
  document.getElementById("welcomeName");

const profilePhoto =
  document.getElementById("profilePhoto");

const logoutBtn =
  document.getElementById("logoutBtn");

function displayLecturer(lecturer) {
  const fullName =
    lecturer.displayName || "Pensyarah";

  const firstName =
    fullName.trim().split(" ")[0];

  lecturerName.textContent = fullName;
  lecturerEmail.textContent = lecturer.email || "";
  welcomeName.textContent = firstName;

  if (lecturer.photoURL) {
    profilePhoto.src = lecturer.photoURL;
    profilePhoto.alt = `Gambar profil ${fullName}`;
  } else {
    profilePhoto.removeAttribute("src");
  }
}

async function saveLecturerProfile(lecturer) {
  const lecturerReference = doc(
    db,
    "lecturers",
    lecturer.uid
  );

  const lecturerSnapshot = await getDoc(
    lecturerReference
  );

  const lecturerData = {
    uid: lecturer.uid,
    name: lecturer.displayName || "Pensyarah",
    email: lecturer.email || "",
    photoURL: lecturer.photoURL || "",
    lastLoginAt: serverTimestamp()
  };

  if (lecturerSnapshot.exists()) {
    await updateDoc(
      lecturerReference,
      lecturerData
    );
  } else {
    await setDoc(lecturerReference, {
      ...lecturerData,
      createdAt: serverTimestamp()
    });
  }
}

onAuthStateChanged(auth, async (lecturer) => {
  if (!lecturer) {
    window.location.replace("index.html");
    return;
  }

  displayLecturer(lecturer);

  try {
    await saveLecturerProfile(lecturer);

    console.log(
      "Profil Pensyarah berjaya disimpan."
    );
  } catch (error) {
    console.error(
      "Profil Pensyarah gagal disimpan:",
      error
    );

    window.alert(
      "Profil Pensyarah tidak dapat disimpan. " +
      "Semak sambungan Firestore."
    );
  }
});

logoutBtn.addEventListener("click", async () => {
  const confirmed = window.confirm(
    "Adakah anda mahu log keluar?"
  );

  if (!confirmed) {
    return;
  }

  logoutBtn.disabled = true;
  logoutBtn.textContent = "Sedang keluar...";

  try {
    await signOut(auth);
    window.location.replace("index.html");
  } catch (error) {
    console.error("Ralat log keluar:", error);

    window.alert(
      "Log keluar tidak berjaya. Sila cuba semula."
    );

    logoutBtn.disabled = false;
    logoutBtn.textContent = "Log Keluar";
  }
});