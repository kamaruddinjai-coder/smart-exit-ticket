import {
  auth,
  db
} from "./firebase-config.js";

import {
  onAuthStateChanged,
  signInAnonymously
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

import {
  doc,
  getDoc,
  serverTimestamp,
  setDoc
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

/* =====================================
   ELEMEN PAPARAN UTAMA
===================================== */

const studentLoading =
  document.getElementById("studentLoading");

const studentError =
  document.getElementById("studentError");

const studentErrorTitle =
  document.getElementById(
    "studentErrorTitle"
  );

const studentErrorText =
  document.getElementById(
    "studentErrorText"
  );

const studentSessionContent =
  document.getElementById(
    "studentSessionContent"
  );

const studentSuccess =
  document.getElementById("studentSuccess");

/* =====================================
   MAKLUMAT SESI
===================================== */

const studentTopic =
  document.getElementById("studentTopic");

const studentCourse =
  document.getElementById("studentCourse");

const studentClass =
  document.getElementById("studentClass");

const studentSessionCode =
  document.getElementById(
    "studentSessionCode"
  );

const studentSubtopicList =
  document.getElementById(
    "studentSubtopicList"
  );

const studentQuestionContainer =
  document.getElementById(
    "studentQuestionContainer"
  );

/* =====================================
   ELEMEN BORANG
===================================== */

const studentResponseForm =
  document.getElementById(
    "studentResponseForm"
  );

const studentName =
  document.getElementById("studentName");

const studentMatric =
  document.getElementById("studentMatric");

const understoodText =
  document.getElementById(
    "understoodText"
  );

const notUnderstoodText =
  document.getElementById(
    "notUnderstoodText"
  );

const studentFormMessage =
  document.getElementById(
    "studentFormMessage"
  );

const submitResponseBtn =
  document.getElementById(
    "submitResponseBtn"
  );

const automaticFeedback =
  document.getElementById(
    "automaticFeedback"
  );

/* =====================================
   MAKLUMAT URL DAN STATUS APLIKASI
===================================== */

const urlParameters =
  new URLSearchParams(
    window.location.search
  );

const sessionId =
  urlParameters.get("session");

let currentStudent = null;
let currentSession = null;
let applicationStarted = false;

/* =====================================
   FUNGSI PAPARAN
===================================== */

function hideMainSections() {
  studentLoading.classList.add("hidden");
  studentError.classList.add("hidden");
  studentSessionContent.classList.add(
    "hidden"
  );
  studentSuccess.classList.add("hidden");
}

function showError(title, message) {
  hideMainSections();

  studentErrorTitle.textContent = title;
  studentErrorText.textContent = message;

  studentError.classList.remove("hidden");
}

function showMessage(text, type) {
  studentFormMessage.textContent = text;

  studentFormMessage.className =
    `message show ${type}`;
}

function clearMessage() {
  studentFormMessage.textContent = "";

  studentFormMessage.className =
    "message";
}

function escapeHTML(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/* =====================================
   PEMPROSESAN DATA PELAJAR
===================================== */

function normaliseResponseKey(
  matricNumber
) {
  return matricNumber
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
}

function getSelectedUnderstandingLevel() {
  const selectedOption =
    document.querySelector(
      'input[name="understandingLevel"]:checked'
    );

  return selectedOption?.value || "";
}

function collectQuestionAnswers() {
  const answerFields = [
    ...document.querySelectorAll(
      ".student-question-answer"
    )
  ];

  return answerFields.map(
    (field, index) => ({
      question:
        currentSession.questions[index] || "",

      answer:
        field.value.trim()
    })
  );
}

/* =====================================
   MASA SESI
===================================== */

function getSessionTimeStatus(
  sessionData
) {
  const currentTime = new Date();

  const startTime =
    sessionData.startAt?.toDate();

  const endTime =
    sessionData.endAt?.toDate();

  if (!startTime || !endTime) {
    return "invalid";
  }

  if (currentTime < startTime) {
    return "not-started";
  }

  if (currentTime > endTime) {
    return "ended";
  }

  return "open";
}

function formatDateTime(timestamp) {
  if (!timestamp?.toDate) {
    return "";
  }

  return new Intl.DateTimeFormat(
    "ms-MY",
    {
      dateStyle: "medium",
      timeStyle: "short"
    }
  ).format(timestamp.toDate());
}

/* =====================================
   PAPARAN SUBTOPIK DAN SOALAN
===================================== */

function renderSubtopics(subtopics) {
  studentSubtopicList.innerHTML =
    subtopics
      .map((subtopic) => `
        <li>
          ${escapeHTML(subtopic)}
        </li>
      `)
      .join("");
}

function renderQuestions(questions) {
  studentQuestionContainer.innerHTML =
    questions
      .map((question, index) => `
        <div class="student-question-item">

          <label
            for="questionAnswer${index}"
          >

            <span
              class="student-question-number"
            >
              ${index + 1}.
            </span>

            ${escapeHTML(question)}

          </label>

          <textarea
            id="questionAnswer${index}"
            class="student-question-answer"
            data-question-index="${index}"
            maxlength="1000"
            placeholder="Masukkan jawapan anda..."
            required
          ></textarea>

        </div>
      `)
      .join("");
}

function displaySession(sessionData) {
  studentTopic.textContent =
    sessionData.topic ||
    "Topik Pembelajaran";

  studentCourse.textContent =
    `${sessionData.courseCode || ""} — ` +
    `${sessionData.courseName || ""}`;

  studentClass.textContent =
    sessionData.className || "-";

  studentSessionCode.textContent =
    sessionData.sessionCode || "-";

  const subtopics =
    Array.isArray(sessionData.subtopics)
      ? sessionData.subtopics
      : [];

  const questions =
    Array.isArray(sessionData.questions)
      ? sessionData.questions
      : [];

  renderSubtopics(subtopics);
  renderQuestions(questions);

  hideMainSections();

  studentSessionContent.classList.remove(
    "hidden"
  );
}

/* =====================================
   DAPATKAN SESI DARIPADA FIRESTORE
===================================== */

async function loadSession() {
  if (!sessionId) {
    showError(
      "Pautan sesi tidak lengkap",
      "Sila gunakan pautan yang diberikan oleh Pensyarah."
    );

    return;
  }

  try {
    const sessionReference =
      doc(
        db,
        "sessions",
        sessionId
      );

    const sessionSnapshot =
      await getDoc(sessionReference);

    if (!sessionSnapshot.exists()) {
      showError(
        "Sesi tidak ditemui",
        "Semak semula pautan atau hubungi Pensyarah."
      );

      return;
    }

    currentSession = {
      id: sessionSnapshot.id,
      ...sessionSnapshot.data()
    };

    if (
      currentSession.status !== "active"
    ) {
      showError(
        "Sesi belum dibuka",
        "Sesi ini masih dalam status draf atau telah ditutup."
      );

      return;
    }

    const timeStatus =
      getSessionTimeStatus(
        currentSession
      );

    if (timeStatus === "not-started") {
      showError(
        "Sesi belum bermula",
        `Sesi akan dibuka pada ${
          formatDateTime(
            currentSession.startAt
          )
        }.`
      );

      return;
    }

    if (timeStatus === "ended") {
      showError(
        "Sesi telah tamat",
        `Tempoh menjawab berakhir pada ${
          formatDateTime(
            currentSession.endAt
          )
        }.`
      );

      return;
    }

    if (timeStatus === "invalid") {
      showError(
        "Tempoh sesi tidak sah",
        "Hubungi Pensyarah untuk menyemak tetapan sesi."
      );

      return;
    }

    displaySession(currentSession);
  } catch (error) {
    console.error(
      "Sesi gagal diperoleh:",
      error
    );

    if (
      error.code === "permission-denied"
    ) {
      showError(
        "Sesi tidak dapat dibuka",
        "Akses kepada sesi telah ditolak. Semak status sesi dan Security Rules."
      );

      return;
    }

    showError(
      "Sesi tidak dapat dibuka",
      `Ralat: ${
        error.code ||
        error.message ||
        "ralat-tidak-diketahui"
      }`
    );
  }
}

/* =====================================
   MAKLUM BALAS AUTOMATIK
===================================== */

function createAutomaticFeedback(level) {
  if (level === "faham") {
    return {
      title: "Syabas!",

      message:
        "Anda menunjukkan tahap kefahaman " +
        "yang baik. Cuba terangkan semula " +
        "topik ini kepada rakan atau hasilkan " +
        "nota ringkas untuk mengukuhkan ingatan."
    };
  }

  if (level === "sebahagian") {
    return {
      title: "Teruskan usaha",

      message:
        "Anda telah memahami sebahagian " +
        "topik. Semak semula bahagian yang " +
        "belum jelas dan kemukakan soalan " +
        "kepada Pensyarah."
    };
  }

  return {
    title: "Jangan berputus asa",

    message:
      "Maklum balas anda membantu Pensyarah " +
      "mengenal pasti bahagian yang memerlukan " +
      "penerangan lanjut. Semak nota asas dan " +
      "dapatkan bimbingan Pensyarah."
  };
}

/* =====================================
   FORMAT NOMBOR MATRIK
===================================== */

studentMatric.addEventListener(
  "input",
  () => {
    const cursorPosition =
      studentMatric.selectionStart;

    studentMatric.value =
      studentMatric.value.toUpperCase();

    studentMatric.setSelectionRange(
      cursorPosition,
      cursorPosition
    );
  }
);

/* =====================================
   HANTAR RESPONS PELAJAR
===================================== */

studentResponseForm.addEventListener(
  "submit",
  async (event) => {
    event.preventDefault();
    clearMessage();

    if (
      !currentStudent ||
      !currentSession
    ) {
      showMessage(
        "Maklumat sesi belum tersedia. Muat semula halaman.",
        "error"
      );

      return;
    }

    if (!currentStudent.isAnonymous) {
      showMessage(
        "Respons mesti dihantar melalui akaun Pelajar Anonymous.",
        "error"
      );

      return;
    }

    if (
      getSessionTimeStatus(
        currentSession
      ) !== "open"
    ) {
      showMessage(
        "Tempoh menjawab sesi ini telah tamat.",
        "error"
      );

      return;
    }

    const responseKey =
      normaliseResponseKey(
        studentMatric.value
      );

    if (responseKey.length < 4) {
      showMessage(
        "Masukkan nombor matrik yang sah.",
        "error"
      );

      return;
    }

    const understandingLevel =
      getSelectedUnderstandingLevel();

    if (!understandingLevel) {
      showMessage(
        "Sila pilih tahap kefahaman.",
        "error"
      );

      return;
    }

    const questionAnswers =
      collectQuestionAnswers();

    const hasEmptyAnswer =
      questionAnswers.some(
        (item) => !item.answer
      );

    if (hasEmptyAnswer) {
      showMessage(
        "Sila jawab semua soalan Pensyarah.",
        "error"
      );

      return;
    }

    const responseId =
      `${sessionId}_${responseKey}`;

    submitResponseBtn.disabled = true;

    submitResponseBtn.textContent =
      "Sedang menghantar...";

    try {
      const responseReference =
        doc(
          db,
          "responses",
          responseId
        );

      /*
        Jangan gunakan getDoc untuk membaca
        respons terdahulu. Security Rules memang
        melarang Pelajar membaca responses.

        Jika dokumen dengan ID yang sama telah
        wujud, setDoc akan menjadi operasi update.
        Security Rules akan menolak operasi tersebut.
      */
      await setDoc(
        responseReference,
        {
          sessionId,
          responseKey,

          studentUid:
            currentStudent.uid,

          lecturerId:
            currentSession.lecturerId,

          classId:
            currentSession.classId,

          className:
            currentSession.className,

          courseCode:
            currentSession.courseCode,

          topic:
            currentSession.topic,

          sessionCode:
            currentSession.sessionCode,

          studentName:
            studentName.value.trim(),

          studentMatric:
            studentMatric.value
              .trim()
              .toUpperCase(),

          understandingLevel,

          understoodText:
            understoodText.value.trim(),

          notUnderstoodText:
            notUnderstoodText.value.trim(),

          questionAnswers,

          submittedAt:
            serverTimestamp()
        }
      );

      const feedback =
        createAutomaticFeedback(
          understandingLevel
        );

      automaticFeedback.innerHTML = `
        <strong>
          ${escapeHTML(feedback.title)}
        </strong>

        ${escapeHTML(feedback.message)}
      `;

      hideMainSections();

      studentSuccess.classList.remove(
        "hidden"
      );

      window.scrollTo({
        top: 0,
        behavior: "smooth"
      });
    } catch (error) {
      console.error(
        "Respons gagal dihantar:",
        error
      );

      if (
        error.code === "permission-denied"
      ) {
        showMessage(
          "Respons ditolak oleh Firestore. " +
          "Pastikan sesi masih aktif, tempoh belum " +
          "tamat dan nombor matrik belum digunakan. " +
          "Kod ralat: permission-denied.",
          "error"
        );

        return;
      }

      showMessage(
        `Respons gagal dihantar. Kod ralat: ${
          error.code ||
          error.message ||
          "ralat-tidak-diketahui"
        }`,
        "error"
      );
    } finally {
      submitResponseBtn.disabled = false;

      submitResponseBtn.textContent =
        "Hantar Exit Ticket";
    }
  }
);

/* =====================================
   AUTHENTICATION PELAJAR
===================================== */

onAuthStateChanged(
  auth,
  async (student) => {
    if (applicationStarted) {
      return;
    }

    if (student) {
      applicationStarted = true;

      if (!student.isAnonymous) {
        showError(
          "Buka sebagai Pelajar",
          "Anda sedang log masuk sebagai Pensyarah. " +
          "Sila buka pautan ini dalam tetingkap " +
          "Incognito atau pada peranti Pelajar."
        );

        return;
      }

      currentStudent = student;

      await loadSession();

      return;
    }

    try {
      await signInAnonymously(auth);
    } catch (error) {
      console.error(
        "Anonymous Authentication gagal:",
        error
      );

      showError(
        "Sambungan Pelajar gagal",
        `Anonymous Authentication gagal. Kod ralat: ${
          error.code ||
          error.message ||
          "ralat-tidak-diketahui"
        }`
      );
    }
  }
);