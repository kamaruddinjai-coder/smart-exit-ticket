import {
  auth,
  db
} from "./firebase-config.js";

import {
  onAuthStateChanged,
  signOut
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-auth.js";

import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  serverTimestamp,
  updateDoc,
  where
} from "https://www.gstatic.com/firebasejs/12.18.0/firebase-firestore.js";

/* Profil Pensyarah */
const lecturerName =
  document.getElementById("lecturerName");

const lecturerEmail =
  document.getElementById("lecturerEmail");

const profilePhoto =
  document.getElementById("profilePhoto");

const logoutBtn =
  document.getElementById("logoutBtn");

/* Borang kelas */
const showClassFormBtn =
  document.getElementById("showClassFormBtn");

const classFormPanel =
  document.getElementById("classFormPanel");

const closeClassFormBtn =
  document.getElementById("closeClassFormBtn");

const cancelClassBtn =
  document.getElementById("cancelClassBtn");

const classForm =
  document.getElementById("classForm");

const classFormTitle =
  document.getElementById("classFormTitle");

const editingClassId =
  document.getElementById("editingClassId");

const courseCode =
  document.getElementById("courseCode");

const courseName =
  document.getElementById("courseName");

const className =
  document.getElementById("className");

const studentCount =
  document.getElementById("studentCount");

const classFormMessage =
  document.getElementById("classFormMessage");

const saveClassBtn =
  document.getElementById("saveClassBtn");

/* Senarai kelas */
const classList =
  document.getElementById("classList");

const classTotalLabel =
  document.getElementById("classTotalLabel");

let currentLecturer = null;
let currentClasses = [];
let stopClassListener = null;

function displayLecturer(lecturer) {
  const fullName =
    lecturer.displayName || "Pensyarah";

  lecturerName.textContent = fullName;
  lecturerEmail.textContent = lecturer.email || "";

  if (lecturer.photoURL) {
    profilePhoto.src = lecturer.photoURL;
    profilePhoto.alt = `Gambar profil ${fullName}`;
  } else {
    profilePhoto.removeAttribute("src");
  }
}

function showFormMessage(text, type) {
  classFormMessage.textContent = text;
  classFormMessage.className =
    `message show ${type}`;
}

function clearFormMessage() {
  classFormMessage.textContent = "";
  classFormMessage.className = "message";
}

function openNewClassForm() {
  classForm.reset();
  editingClassId.value = "";

  classFormTitle.textContent =
    "Tambah Kelas Baharu";

  saveClassBtn.textContent = "Simpan Kelas";

  clearFormMessage();
  classFormPanel.classList.remove("hidden");
  courseCode.focus();
}

function openEditClassForm(classData) {
  editingClassId.value = classData.id;
  courseCode.value = classData.courseCode;
  courseName.value = classData.courseName;
  className.value = classData.className;
  studentCount.value = classData.studentCount;

  classFormTitle.textContent = "Edit Kelas";
  saveClassBtn.textContent = "Simpan Perubahan";

  clearFormMessage();
  classFormPanel.classList.remove("hidden");
  classFormPanel.scrollIntoView({
    behavior: "smooth",
    block: "start"
  });
}

function closeClassForm() {
  classForm.reset();
  editingClassId.value = "";
  clearFormMessage();

  classFormTitle.textContent =
    "Tambah Kelas Baharu";

  saveClassBtn.textContent = "Simpan Kelas";

  classFormPanel.classList.add("hidden");
}

function escapeHTML(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderClasses() {
  classTotalLabel.textContent =
    `${currentClasses.length} kelas`;

  if (currentClasses.length === 0) {
    classList.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">K</div>

        <h3>Belum ada kelas</h3>

        <p>
          Tekan “Tambah Kelas” untuk
          mendaftarkan kelas pertama.
        </p>
      </div>
    `;

    return;
  }

  const sortedClasses = [...currentClasses].sort(
    (firstClass, secondClass) => {
      const firstTime =
        firstClass.createdAt?.seconds || 0;

      const secondTime =
        secondClass.createdAt?.seconds || 0;

      return secondTime - firstTime;
    }
  );

  classList.innerHTML = `
    <div class="class-list">

      ${sortedClasses.map((classData) => `
        <article class="class-item">

          <div class="class-main">

            <div class="class-heading">
              <h3>
                ${escapeHTML(classData.className)}
              </h3>

              <span class="course-badge">
                ${escapeHTML(classData.courseCode)}
              </span>
            </div>

            <p>
              ${escapeHTML(classData.courseName)}
            </p>

            <div class="class-meta">
              <span>
                ${Number(classData.studentCount)} pelajar
              </span>

              <span>
                ${classData.isActive
                  ? "Kelas aktif"
                  : "Kelas tidak aktif"}
              </span>
            </div>

          </div>

          <div class="class-actions">

            <button
              type="button"
              class="edit-button"
              data-action="edit"
              data-class-id="${classData.id}"
            >
              Edit
            </button>

            <button
              type="button"
              class="delete-button"
              data-action="delete"
              data-class-id="${classData.id}"
            >
              Padam
            </button>

          </div>

        </article>
      `).join("")}

    </div>
  `;
}

function listenToClasses(lecturerId) {
  const classesQuery = query(
    collection(db, "classes"),
    where("lecturerId", "==", lecturerId)
  );

  stopClassListener = onSnapshot(
    classesQuery,
    (snapshot) => {
      currentClasses =
        snapshot.docs.map((classDocument) => ({
          id: classDocument.id,
          ...classDocument.data()
        }));

      renderClasses();
    },
    (error) => {
      console.error(
        "Gagal mendapatkan kelas:",
        error
      );

      classList.innerHTML = `
        <div class="empty-state">
          <h3>Data kelas tidak dapat dibaca</h3>

          <p>
            Semak Firestore Security Rules
            dan cuba semula.
          </p>
        </div>
      `;
    }
  );
}

showClassFormBtn.addEventListener(
  "click",
  openNewClassForm
);

closeClassFormBtn.addEventListener(
  "click",
  closeClassForm
);

cancelClassBtn.addEventListener(
  "click",
  closeClassForm
);

classList.addEventListener(
  "click",
  async (event) => {
    const actionButton =
      event.target.closest("[data-action]");

    if (!actionButton) {
      return;
    }

    const selectedClassId =
      actionButton.dataset.classId;

    const selectedClass =
      currentClasses.find(
        (classData) =>
          classData.id === selectedClassId
      );

    if (!selectedClass) {
      return;
    }

    if (actionButton.dataset.action === "edit") {
      openEditClassForm(selectedClass);
      return;
    }

    if (actionButton.dataset.action === "delete") {
      const confirmed = window.confirm(
        `Padam kelas ${selectedClass.className}?`
      );

      if (!confirmed) {
        return;
      }

      actionButton.disabled = true;
      actionButton.textContent = "Memadam...";

      try {
        await deleteDoc(
          doc(db, "classes", selectedClassId)
        );
      } catch (error) {
        console.error(
          "Kelas gagal dipadam:",
          error
        );

        window.alert(
          `Kelas gagal dipadam: ${
            error.code || "ralat-tidak-diketahui"
          }`
        );

        actionButton.disabled = false;
        actionButton.textContent = "Padam";
      }
    }
  }
);

classForm.addEventListener(
  "submit",
  async (event) => {
    event.preventDefault();

    if (!currentLecturer) {
      showFormMessage(
        "Sesi log masuk tidak ditemui.",
        "error"
      );

      return;
    }

    const totalStudents =
      Number.parseInt(studentCount.value, 10);

    if (
      Number.isNaN(totalStudents) ||
      totalStudents < 1 ||
      totalStudents > 100
    ) {
      showFormMessage(
        "Bilangan pelajar mestilah antara 1 hingga 100.",
        "error"
      );

      return;
    }

    const classData = {
      className: className.value
        .trim()
        .toUpperCase(),
      courseCode: courseCode.value
        .trim()
        .toUpperCase(),
      courseName: courseName.value.trim(),
      studentCount: totalStudents,
      isActive: true,
      updatedAt: serverTimestamp()
    };

    saveClassBtn.disabled = true;

    const selectedClassId =
      editingClassId.value;

    try {
      if (selectedClassId) {
        saveClassBtn.textContent =
          "Sedang mengemas kini...";

        await updateDoc(
          doc(db, "classes", selectedClassId),
          classData
        );

        showFormMessage(
          "Maklumat kelas berjaya dikemas kini.",
          "success"
        );
      } else {
        saveClassBtn.textContent =
          "Sedang menyimpan...";

        await addDoc(
          collection(db, "classes"),
          {
            ...classData,
            lecturerId: currentLecturer.uid,
            createdAt: serverTimestamp()
          }
        );

        showFormMessage(
          "Kelas berjaya disimpan.",
          "success"
        );
      }

      window.setTimeout(() => {
        closeClassForm();
      }, 800);
    } catch (error) {
      console.error(
        "Kelas gagal disimpan:",
        error
      );

      showFormMessage(
        `Operasi gagal: ${
          error.code || "ralat-tidak-diketahui"
        }`,
        "error"
      );
    } finally {
      saveClassBtn.disabled = false;

      saveClassBtn.textContent =
        selectedClassId
          ? "Simpan Perubahan"
          : "Simpan Kelas";
    }
  }
);

onAuthStateChanged(auth, (lecturer) => {
  if (!lecturer) {
    window.location.replace("index.html");
    return;
  }

  currentLecturer = lecturer;
  displayLecturer(lecturer);

  if (stopClassListener) {
    stopClassListener();
  }

  listenToClasses(lecturer.uid);
});

logoutBtn.addEventListener("click", async () => {
  const confirmed = window.confirm(
    "Adakah anda mahu log keluar?"
  );

  if (!confirmed) {
    return;
  }

  try {
    if (stopClassListener) {
      stopClassListener();
    }

    await signOut(auth);
    window.location.replace("index.html");
  } catch (error) {
    console.error("Ralat log keluar:", error);

    window.alert(
      "Log keluar tidak berjaya. Sila cuba semula."
    );
  }
});